#ifndef _STDBOOL_H
#define _STDBOOL_H

#undef bool
#undef true
#undef false

#define bool	unsigned int
#define true	1
#define false	0

#endif
