#ifndef _SCRYPT_PLATFORM_H_
#define	_SCRYPT_PLATFORM_H_

#include "arch.h"
#endif
